from django.shortcuts import render

def home(request):
	return render(request, 'home.html', {'user': "cjmmacalua"})

def about(request):
	my_name = "Christer John M. Macalua"
	return render(request, 'about.html', {"myname": my_name})

def contact(request):
	return render(request, 'contact-us.html', {'user': "cjmmacalua"})

def listings(request):
	return render(request, 'listings.html', {'user': "cjmmacalua"})